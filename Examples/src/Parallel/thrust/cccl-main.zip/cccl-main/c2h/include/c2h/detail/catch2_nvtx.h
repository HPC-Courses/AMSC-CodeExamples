// SPDX-FileCopyrightText: Copyright (c) 2011-2026, NVIDIA CORPORATION. All rights reserved.
// SPDX-License-Identifier: BSD-3-Clause

#pragma once

#include <cuda/std/detail/__config>

#include <cuda/__nvtx/nvtx.h>

#include <catch2/interfaces/catch_interfaces_capture.hpp>

namespace c2h::detail
{
struct nvtx_c2h_domain
{
  static constexpr const char* name = "C2H";
};

template <typename T>
class nvtx_fixture
{
#if _CCCL_HAS_NVTX3()
  ::nvtx3::v1::scoped_range_in<nvtx_c2h_domain> nvtx_range{Catch::getResultCapture().getCurrentTestName()};
#endif // _CCCL_HAS_NVTX3()
};
} // namespace c2h::detail
