# Windows PowerShell 5.1 in a bare image may still default to TLS 1.0, which
# astral.sh and aka.ms both reject.
[Net.ServicePointManager]::SecurityProtocol =
    [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

function Invoke-Checked {
    <#
    .SYNOPSIS
        Runs a script block and throws if the last native command in it exits
        non-zero. $ErrorActionPreference = "Stop" does not make native commands
        (python/pip/pytest/...) throw, so their $LASTEXITCODE must be checked
        explicitly; this wraps that boilerplate into one call.
    .EXAMPLE
        Invoke-Checked { & $python -m pip install pytest } "pip install failed"
    #>
    param(
        [Parameter(Mandatory, Position = 0)][scriptblock]$ScriptBlock,
        [Parameter(Position = 1)][string]$ErrorMessage = "Native command failed"
    )
    & $ScriptBlock
    if ($LASTEXITCODE -ne 0) {
        throw "$ErrorMessage (exit code $LASTEXITCODE)"
    }
}

function Get-Python {
    <#
    .SYNOPSIS
        Returns the path of the Python interpreter satisfying the supplied
        version, installing it via uv if necessary.
    .PARAMETER Version
        A string in the form 'M.m' (e.g., '3.10', '3.13') or a free-threaded
        version such as '3.14t'.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, Position = 0)]
        [ValidatePattern('^\d+\.\d+t?$')]
        [string]$Version
    )

    # Install uv if not present. uv downloads pre-built CPython binaries --
    # no compilation, no build dependencies, no pyenv-win required.
    if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
        Write-Host "Installing uv..."
        Invoke-RestMethod https://astral.sh/uv/install.ps1 | Invoke-Expression
        # uv installs to $HOME\.local\bin on Windows
        $uvBin = Join-Path $HOME '.local\bin'
        $Env:PATH = $uvBin + ";" + $Env:PATH
    }

    Write-Host "Creating Python $Version venv via uv..."
    $venvDir = Join-Path $HOME '.cccl-venv'
    & uv venv --seed --python $Version $venvDir
    if ($LASTEXITCODE -ne 0) {
        throw [System.InvalidOperationException]::new(
            "Failed to create Python $Version venv via uv."
        )
    }

    $exe = Join-Path $venvDir 'Scripts\python.exe'
    if (-not (Test-Path $exe)) {
        throw [System.InvalidOperationException]::new(
            "Could not find python.exe in venv at $exe"
        )
    }

    Write-Host "Python $Version at: $exe"

    # Add venv Scripts dir to PATH so bare `python` and `pip` work.
    $scriptsDir = Join-Path $venvDir 'Scripts'
    $Env:PATH = $scriptsDir + ";" + $Env:PATH

    return $exe
}

function Get-RepoRoot {
    return (Resolve-Path "$PSScriptRoot/../..")
}

function Get-CudaMajor {
    <#
    .SYNOPSIS
        Gets the CUDA major version for this container instance (e.g. '12' or
        '13').  Defaults to '13' if no match can be found.
    #>
    if ($env:CUDA_PATH) {
        $nvcc = Join-Path $env:CUDA_PATH "bin/nvcc.exe"
        if (Test-Path $nvcc) {
            $out = & $nvcc --version 2>&1
            $text = ($out -join "`n")
            if ($text -match 'release\s+(\d+)\.') { return $Matches[1] }
        }
        # Fallback: parse major from CUDA_PATH like ...\v13.0 or ...\CUDA\13
        $pathMatch = [regex]::Match($env:CUDA_PATH, 'v?(\d+)(?:\.\d+)?')
        if ($pathMatch.Success) { return $pathMatch.Groups[1].Value }
    }
    # The minimal test container has no CUDA toolkit at all, by design, so the
    # caller passes the version resolved outside it.
    if ($env:CCCL_CUDA_VERSION -match '^(\d+)\.') { return $Matches[1] }
    return '13'
}

function Get-CudaVersion {
    <#
    .SYNOPSIS
        Gets the CUDA major.minor version for this container instance (e.g.
        '12.9' or '13.0').  Defaults to '13.0' if no match can be found.
    #>
    if ($env:CUDA_PATH) {
        $nvcc = Join-Path $env:CUDA_PATH "bin/nvcc.exe"
        if (Test-Path $nvcc) {
            $out = & $nvcc --version 2>&1
            $text = ($out -join "`n")
            if ($text -match 'release\s+(\d+\.\d+)') { return $Matches[1] }
        }
        # Fallback: parse major.minor from CUDA_PATH like ...\v13.0
        $pathMatch = [regex]::Match($env:CUDA_PATH, 'v?(\d+\.\d+)')
        if ($pathMatch.Success) { return $pathMatch.Groups[1].Value }
    }
    # See Get-CudaMajor.
    if ($env:CCCL_CUDA_VERSION -match '^\d+\.\d+$') { return $env:CCCL_CUDA_VERSION }
    return '13.0'
}

function Get-CtkTestMode {
    <#
    .SYNOPSIS
        Validates and normalizes a CTK test mode passed as -Mode (forwarded from
        the -ctk-mode arg): 'pinned' (default; empty means pinned), 'latest', or
        'sysctk'. Throws on any other value (fail loud on a typo'd mode). Returns
        the lowercased mode.
    #>
    param([string]$Mode = "")
    if ([string]::IsNullOrEmpty($Mode)) { return "pinned" }
    $Mode = $Mode.ToLowerInvariant()
    if (-not ($Mode -in @("pinned", "latest", "sysctk"))) {
        throw "Invalid ctk mode '$Mode' (expected pinned|latest|sysctk)"
    }
    return $Mode
}

function Set-CtkPin {
    <#
    .SYNOPSIS
        Configures cuda-toolkit pinning for this lane per the -Mode arg (see
        Get-CtkTestMode): 'pinned' (default) pins cuda-toolkit to the container's
        CTK major.minor via PIP_CONSTRAINT; 'latest' and 'sysctk' leave it
        unpinned ('sysctk' installs no cuda-toolkit wheel at all -- the
        system-provided toolkit is used).
    #>
    param([string]$Mode = "")
    if ((Get-CtkTestMode $Mode) -eq "pinned") {
        $cudaVersion = Get-CudaVersion
        $env:PIP_CONSTRAINT = Join-Path ([System.IO.Path]::GetTempPath()) "ctk-constraint.txt"
        "cuda-toolkit==$cudaVersion.*" | Out-File -FilePath $env:PIP_CONSTRAINT -Encoding ascii
    } else {
        # latest / sysctk: no pin. Clear any inherited constraint so it cannot
        # affect the resolve.
        Remove-Item Env:\PIP_CONSTRAINT -ErrorAction SilentlyContinue
    }
}

function Get-CtkExtraFlavor {
    <#
    .SYNOPSIS
        Returns the pip-extra toolkit "flavor" for the given -Mode: 'sysctk' when
        the mode is sysctk (rely on the system-provided CUDA toolkit) or 'cu'
        otherwise (pip-installed toolkit). Combine with the CUDA major, e.g.
        "minimal-$(Get-CtkExtraFlavor $CtkMode)$cudaMajor".
    #>
    param([string]$Mode = "")
    if ((Get-CtkTestMode $Mode) -eq "sysctk") { return "sysctk" }
    return "cu"
}

function Convert-ToUnixPath {
    Param([Parameter(Mandatory = $true)][string]$p)
    return ($p -replace "\\", "/")
}

function Get-CudaCcclWheel {
    <#
    .SYNOPSIS
        Returns the path of the cuda-cccl wheel artifact to use in the context
        of a GitHub Actions CI test script.
    #>
    Param()

    $repoRoot = Get-RepoRoot
    if ($env:GITHUB_ACTIONS) {
        Push-Location $repoRoot
        try {
            $wheelArtifactName = (& bash -lc "ci/util/workflow/get_wheel_artifact_name.sh").Trim()
            if (-not $wheelArtifactName) { throw 'Failed to resolve wheel artifact name' }
            $repoRootPosix = Convert-ToUnixPath $repoRoot
            # Ensure output from downloader goes to console, not function return pipeline
            $null = (& bash -lc "ci/util/artifacts/download.sh $wheelArtifactName $repoRootPosix" 2>&1 | Out-Host)
            if ($LASTEXITCODE -ne 0) { throw "Failed to download wheel artifact '$wheelArtifactName'" }
        }
        finally { Pop-Location }
    }

    $wheelhouse = Join-Path $repoRoot 'wheelhouse'
    $wheelPath = Get-OnePathMatch -Path $wheelhouse -Pattern '^cuda_cccl-.*\.whl' -File
    return $wheelPath
}

function Get-OnePathMatch {
    <#
    .SYNOPSIS
        Returns a single path (file or directory) match for a given pattern,
        throwing an error if there were no matches or more than one match.
    #>
    [CmdletBinding(DefaultParameterSetName = 'FileSet')]
    param(
        [Parameter(Mandatory)]
        [string] $Path,

        [Parameter(Mandatory)]
        [string] $Pattern,

        [Parameter(Mandatory, ParameterSetName = 'FileSet')]
        [switch] $File,

        [Parameter(Mandatory, ParameterSetName = 'DirSet')]
        [switch] $Directory,

        [switch] $Recurse
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        throw "Path not found or not a directory: $Path"
    }

    $gciArgs = @{
        LiteralPath = $Path
        ErrorAction = 'SilentlyContinue'
    }

    if ($Recurse) { $gciArgs['Recurse'] = $true }
    if ($PSCmdlet.ParameterSetName -eq 'FileSet') {
        $gciArgs['File'] = $true
    }
    else {
        $gciArgs['Directory'] = $true
    }

    $pathMatches = @(
        Get-ChildItem @gciArgs |
        Where-Object { $_.Name -match $Pattern } |
        Select-Object -ExpandProperty FullName
    )

    if ($pathMatches.Count -ne 1) {
        $kind = if ($PSCmdlet.ParameterSetName -eq 'FileSet') { 'file' }
        else { 'directory' }
        $indented = ($pathMatches | ForEach-Object { "    $_" }) -join "`n"

        $msg = @"
Expected exactly one $kind name matching regex:
  $Pattern
under:
  $Path
Found:
  $($pathMatches.Count)

$indented
"@
        throw $msg
    }

    return $pathMatches[0]
}

function Install-MsvcRuntime {
    <#
    .SYNOPSIS
        Ensures the MSVC runtime redistributable is present.
    .DESCRIPTION
        Server Core ships no MSVC runtime, and C++ Python extensions that do not
        bundle their own link against it. The cuda-cccl wheel bundles its
        runtime (delvewheel) and must never need this, so the compute lanes run
        without it. The examples lane still installs it for the CuPy wheel on
        PyPI, which imports the system msvcp140.dll (cupy/cupy#10316).
        vcruntime140*.dll ship next to some interpreters, which makes
        msvcp140.dll the reliable probe.

        A no-op wherever the runtime already exists, so it costs nothing in the
        devcontainer.
    #>
    $msvcp = Join-Path $env:SystemRoot 'System32\msvcp140.dll'
    if (Test-Path $msvcp) { return }

    Write-Host "Installing the MSVC runtime redistributable..."
    $installer = Join-Path $env:TEMP 'vc_redist.x64.exe'
    Invoke-WebRequest -UseBasicParsing `
        -Uri 'https://aka.ms/vs/17/release/vc_redist.x64.exe' -OutFile $installer
    Start-Process -Wait -FilePath $installer -ArgumentList '/quiet', '/norestart'
    if (-not (Test-Path $msvcp)) {
        throw "vc_redist.x64.exe did not install msvcp140.dll."
    }
}

function Assert-MinimalEnvironment {
    <#
    .SYNOPSIS
        Proves the claim the minimal container exists to make: that nothing here
        but Python and the wheel's declared dependencies is available.
    .DESCRIPTION
        Without this the isolation is merely assumed -- swap the base image for
        one carrying a toolchain and every lane would keep passing while testing
        nothing. A no-op outside the container, where a compiler and a CUDA
        toolkit are legitimately present.

        The MSVC *runtime* some payloads install is deliberately not checked: it
        is a Windows prerequisite for their dependencies, not a compiler.
    #>
    if ($env:CCCL_INSIDE_MINIMAL_CONTAINER -ne '1') { return }

    $found = @()
    foreach ($tool in @('cl.exe', 'link.exe', 'nvcc.exe')) {
        $cmd = Get-Command $tool -ErrorAction SilentlyContinue
        if ($cmd) { $found += "$tool ($($cmd.Source))" }
    }
    if ($env:CUDA_PATH) { $found += "CUDA_PATH=$($env:CUDA_PATH)" }
    # Guarded: Join-Path throws on a null root, and with ErrorActionPreference
    # Stop that would mask the check it is part of.
    if ($env:ProgramFiles) {
        $ctkDir = Join-Path $env:ProgramFiles 'NVIDIA GPU Computing Toolkit\CUDA'
        if (Test-Path $ctkDir) { $found += $ctkDir }
    }

    if ($found.Count -gt 0) {
        $list = ($found | ForEach-Object { "    $_" }) -join "`n"
        throw (
            "This is supposed to be a minimal environment, but it provides:`n$list`n" +
            "The lane cannot tell whether cuda.compute depends only on its declared " +
            "pip dependencies while these are present. Check the container image."
        )
    }
    Write-Host "Minimal environment confirmed: no host compiler, no system CUDA toolkit."
}

function Test-FreeThreadedPython {
    <#
    .SYNOPSIS
    True when the given interpreter is a free-threaded (GIL-disabled) build.

    .DESCRIPTION
    Mirrors is_free_threaded_python in ci/pyenv_helper.sh. Ask the interpreter
    rather than matching the version string ("3.14t"): a string match silently
    stops firing the day a 3.15t appears, and the free-threading coverage would
    vanish with no test failure to notice it.

    Reports what the build supports, not whether the GIL happens to be on right
    now (PYTHON_GIL=1 can re-enable it). Callers that need the GIL genuinely off
    assert that separately, so a mis-set PYTHON_GIL fails loudly instead of
    silently skipping.

    The probe prints a sentinel and anything else throws. An exit-code probe
    would read a crashed probe as "GIL build" and silently skip the
    free-threading coverage this function exists to gate.
    #>
    Param([Parameter(Mandatory = $true)][string]$Python)

    # Outer double / inner single quotes: Windows PowerShell 5.1 passes native
    # arguments without escaping embedded double quotes, so a double-quoted
    # Python literal reaches python.exe with its quotes stripped.
    $probe = (& $Python -c "import sysconfig; print('FT=%d' % (sysconfig.get_config_var('Py_GIL_DISABLED') in (1, '1')))" | Out-String).Trim()
    # Capture the exit code before anything else can disturb it. A probe that
    # printed a sentinel but exited nonzero is still a failed probe, matching the
    # bash is_free_threaded_python, which treats any nonzero exit as an error.
    $exitCode = $LASTEXITCODE
    if ($exitCode -eq 0) {
        switch ($probe) {
            'FT=1' { return $true }
            'FT=0' { return $false }
        }
    }
    throw "free-threading probe failed (exit code $exitCode, output '$probe'); expected exit 0 with FT=0 or FT=1"
}

Export-ModuleMember -Function Invoke-Checked, Get-Python, Assert-MinimalEnvironment, Install-MsvcRuntime, Get-CudaMajor, Get-CudaVersion, Set-CtkPin, Get-CtkExtraFlavor, Convert-ToUnixPath, Get-RepoRoot, Get-CudaCcclWheel, Get-OnePathMatch, Test-FreeThreadedPython
