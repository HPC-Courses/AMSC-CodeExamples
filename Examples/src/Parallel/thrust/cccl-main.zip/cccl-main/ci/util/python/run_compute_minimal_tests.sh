#!/usr/bin/env bash
# Test payload: the numba-free (minimal extra) cuda.compute suite.
# Invoked by ci/test_cuda_compute_minimal_python.sh, which has already
# put the cuda_cccl wheel in wheelhouse/.
#
# Runs in the minimal container: nothing here may assume more than Python and
# the wheel's declared deps (docs/infrastructure/ci/references/ci_scripts.rst).

set -euo pipefail

ci_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
repo_root="$(cd "$ci_dir/.." && pwd)"
# shellcheck source=ci/pyenv_helper.sh
source "$ci_dir/pyenv_helper.sh"

python_payload_init "$@"

# Install cuda_cccl with the minimal CUDA extra. This intentionally avoids the
# full cu*/sysctk* extras because those pull in numba/numba-cuda. The flavor is
# "cu" (pip toolkit) or "sysctk" (system toolkit) per the -ctk-mode arg.
CUDA_CCCL_WHEEL_PATH="$(cuda_cccl_wheel_path)"
ctk_flavor="$(ctk_extra_flavor "${ctk_mode}")"
python -m pip install "${CUDA_CCCL_WHEEL_PATH}[minimal-${ctk_flavor}${cuda_major_version}]"
python -m pip install pytest pytest-xdist

cd "${repo_root}/python/cuda_cccl/tests/"
python -m pytest -n 6 -v compute/test_no_numba.py compute/test_raw_op.py
if is_free_threaded_python; then
  # Fail fast if the interpreter is not actually GIL-free (wrong build /
  # PYTHON_GIL=1). The stress tests below check this themselves, but the
  # pytest-run-parallel sweep does NOT catch a GIL that is enabled from the
  # start -- it would run threads GIL-serialized and pass vacuously. (A GIL
  # *re-enabled mid-run* by a non-free-threaded import IS caught by the plugin,
  # which is why we do not pass --ignore-gil-enabled.) One check up front covers
  # both and gives one clear failure instead of one per stress test.
  python -c "import sys; assert not sys._is_gil_enabled(), 'GIL is enabled; free-threading tests have no signal'"

  # Select only tests that support the minimal extra, so pytest does not collect
  # tests needing a JIT backend the minimal extras do not install. These tests
  # provide their own worker threads, so keep pytest in a single process.
  # The serialization node-ids are module-skipped on the v2 backend today and
  # will start running there automatically once v2 gains serialization support.
  python -m pytest -n 0 -v \
    compute/test_free_threading_stress.py \
    compute/test_multi_cc_serialization.py::test_aot_build_result_load_failure_is_shared_and_retryable \
    compute/test_multi_cc_serialization.py::test_aot_serialization_waits_for_canonical_first_load

  # Broad thread-safety sweep (pytest-run-parallel): re-run the numba-free
  # functional suite with each test executed concurrently across threads
  # (barrier-synchronized start), stressing the process-wide build cache,
  # single-flight coordination, and the Cython bindings from many threads at
  # once. Complements test_free_threading_stress.py above, which targets specific
  # shared-object scenarios by hand. -n 0 so the threads share one interpreter.
  #
  # --parallel-threads=2 matches CuPy's free-threading CI (the closest GPU
  # precedent); a small fixed count bounds GPU-memory pressure from concurrent
  # kernels and stays reproducible across runners, unlike =auto (the runner's
  # logical-core count).
  #
  # pytest-run-parallel is only used by this sweep, so install it on the
  # free-threaded path rather than for every minimal (e.g. GIL-enabled 3.14) run.
  python -m pip install pytest-run-parallel

  # The swept files are the ones marked no_numba module-wide, i.e. everything
  # the minimal extras can run.
  python -m pytest -n 0 -v --parallel-threads=2 \
    compute/test_no_numba.py compute/test_raw_op.py
fi
