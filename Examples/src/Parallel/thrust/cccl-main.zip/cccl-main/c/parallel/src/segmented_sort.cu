//===----------------------------------------------------------------------===//
//
// Part of CUDA Experimental in CUDA C++ Core Libraries,
// under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES.
//
//===----------------------------------------------------------------------===//

#include <cub/detail/choose_offset.cuh> // cub::detail::choose_offset_t
#include <cub/detail/launcher/cuda_driver.cuh> // cub::detail::CudaDriverLauncherFactory
#include <cub/device/dispatch/dispatch_segmented_sort.cuh> // cub::DispatchSegmentedSort
#include <cub/device/dispatch/kernels/kernel_segmented_sort.cuh> // DeviceSegmentedSort kernels
#include <cub/device/dispatch/tuning/tuning_segmented_sort.cuh>
#include <cub/thread/thread_load.cuh> // cub::LoadModifier

#include <cuda/__type_traits/is_trivially_copyable.h>

#include <cstdlib>
#include <cstring>
#include <exception> // std::exception
#include <format> // std::format
#include <mutex>
#include <string> // std::string
#include <string_view> // std::string_view
#include <type_traits> // std::is_same_v
#include <unordered_map>
#include <vector>

#include "jit_templates/templates/input_iterator.h"
#include "jit_templates/templates/operation.h"
#include "jit_templates/templates/output_iterator.h"
#include "jit_templates/traits.h"
#include "util/context.h"
#include "util/errors.h"
#include "util/indirect_arg.h"
#include "util/nvjitlink.h"
#include "util/serialization.h"
#include "util/types.h"
#include <cccl/c/segmented_sort.h>
#include <cccl/c/serialization.h>
#include <cccl/c/types.h> // cccl_type_info
#include <nvrtc/command_list.h>
#include <nvrtc/ltoir_list_appender.h>
#include <util/build_utils.h>

struct device_segmented_sort_policy_selector;
struct device_three_way_partition_policy_selector;
using OffsetT = ptrdiff_t;
static_assert(std::is_same_v<cub::detail::choose_signed_offset_t<OffsetT>, OffsetT>, "OffsetT must be long");

// check we can map OffsetT to cuda::std::int64_t
static_assert(std::is_signed_v<OffsetT>);
static_assert(sizeof(OffsetT) == sizeof(cuda::std::int64_t));

namespace segmented_sort
{
std::string get_device_segmented_sort_fallback_kernel_name(
  std::string_view start_offset_iterator_t,
  std::string_view end_offset_iterator_t,
  std::string_view key_t,
  std::string_view value_t,
  cccl_sort_order_t sort_order)
{
  std::string policy_selector_t;
  check(cccl_type_name_from_nvrtc<device_segmented_sort_policy_selector>(&policy_selector_t));

  std::string offset_t;
  check(cccl_type_name_from_nvrtc<OffsetT>(&offset_t));

  /*
  template <SortOrder Order,             // 0 (ascending)
            typename PolicySelector,     // 1
            typename KeyT,               // 2
            typename ValueT,             // 3
            typename BeginOffsetIteratorT, // 4
            typename EndOffsetIteratorT,   // 5
            typename OffsetT>              // 6
   DeviceSegmentedSortFallbackKernel(...);
  */
  return std::format(
    "cub::detail::segmented_sort::DeviceSegmentedSortFallbackKernel<{0}, {1}, {2}, {3}, {4}, {5}, {6}>",
    (sort_order == CCCL_ASCENDING) ? "cub::SortOrder::Ascending" : "cub::SortOrder::Descending",
    policy_selector_t, // 0
    key_t, // 1
    value_t, // 2
    start_offset_iterator_t, // 3
    end_offset_iterator_t, // 4
    offset_t); // 5
}

std::string get_device_segmented_sort_kernel_small_name(
  std::string_view start_offset_iterator_t,
  std::string_view end_offset_iterator_t,
  std::string_view key_t,
  std::string_view value_t,
  cccl_sort_order_t sort_order)
{
  std::string chained_policy_t;
  check(cccl_type_name_from_nvrtc<device_segmented_sort_policy_selector>(&chained_policy_t));

  std::string offset_t;
  check(cccl_type_name_from_nvrtc<OffsetT>(&offset_t));

  /*
  template <SortOrder Order,             // 0 (ascending)
            typename ChainedPolicyT,     // 1
            typename KeyT,               // 2
            typename ValueT,             // 3
            typename BeginOffsetIteratorT, // 4
            typename EndOffsetIteratorT,   // 5
            typename OffsetT>              // 6
   DeviceSegmentedSortKernelSmall(...);
  */
  return std::format(
    "cub::detail::segmented_sort::DeviceSegmentedSortKernelSmall<{0}, {1}, {2}, {3}, {4}, {5}, {6}>",
    (sort_order == CCCL_ASCENDING) ? "cub::SortOrder::Ascending" : "cub::SortOrder::Descending",
    chained_policy_t, // 0
    key_t, // 1
    value_t, // 2
    start_offset_iterator_t, // 3
    end_offset_iterator_t, // 4
    offset_t); // 5
}

std::string get_device_segmented_sort_kernel_large_name(
  std::string_view start_offset_iterator_t,
  std::string_view end_offset_iterator_t,
  std::string_view key_t,
  std::string_view value_t,
  cccl_sort_order_t sort_order)
{
  std::string chained_policy_t;
  check(cccl_type_name_from_nvrtc<device_segmented_sort_policy_selector>(&chained_policy_t));

  std::string offset_t;
  check(cccl_type_name_from_nvrtc<OffsetT>(&offset_t));

  /*
  template <SortOrder Order,             // 0 (ascending)
            typename ChainedPolicyT,     // 1
            typename KeyT,               // 2
            typename ValueT,             // 3
            typename BeginOffsetIteratorT, // 4
            typename EndOffsetIteratorT,   // 5
            typename OffsetT>              // 6
   DeviceSegmentedSortKernelLarge(...);
  */
  return std::format(
    "cub::detail::segmented_sort::DeviceSegmentedSortKernelLarge<{0}, {1}, {2}, {3}, {4}, {5}, {6}>",
    (sort_order == CCCL_ASCENDING) ? "cub::SortOrder::Ascending" : "cub::SortOrder::Descending",
    chained_policy_t, // 0
    key_t, // 1
    value_t, // 2
    start_offset_iterator_t, // 3
    end_offset_iterator_t, // 4
    offset_t); // 5
}

struct selector_state_t
{
  OffsetT threshold;
  void* begin_offsets;
  void* end_offsets;
  cub::detail::segmented_sort::global_segment_offset_t base_segment_offset;

  void initialize(OffsetT offset, indirect_iterator_t begin_offset_iterator, indirect_iterator_t end_offset_iterator)
  {
    threshold = offset;
    // If offsets are raw device pointers, unwrap the stored pointer-to-pointer
    // from the iterator state so device code can index it directly.
    begin_offsets       = *static_cast<void**>(begin_offset_iterator.ptr);
    end_offsets         = *static_cast<void**>(end_offset_iterator.ptr);
    base_segment_offset = 0;
  }
};

cccl_op_t make_segments_selector_op(
  cccl_iterator_t begin_offset_iterator,
  cccl_iterator_t end_offset_iterator,
  const char* selector_op_name,
  const char* comparison,
  const char** compile_args,
  size_t num_compile_args,
  const char** lto_opts,
  size_t num_lto_opts)
{
  cccl_op_t selector_op{};
  std::string offset_t;
  check(cccl_type_name_from_nvrtc<OffsetT>(&offset_t));

  const std::string code = std::format(
    R"XXX(
#include <cub/device/dispatch/kernels/kernel_segmented_sort.cuh>

extern "C" __device__ void {0}(void* state_ptr, const void* arg_ptr, void* result_ptr)
{{
  using cub::detail::segmented_sort::local_segment_index_t;
  using cub::detail::segmented_sort::global_segment_offset_t;

  struct state_t {{
    {1} threshold;
    void* begin_offsets;
    void* end_offsets;
    global_segment_offset_t base_segment_offset;
  }};

  auto* st = static_cast<state_t*>(state_ptr);
  const local_segment_index_t sid = *static_cast<const local_segment_index_t*>(arg_ptr);
  const global_segment_offset_t index = st->base_segment_offset + static_cast<global_segment_offset_t>(sid);
  const {2} begin = static_cast<const {2}*>(st->begin_offsets)[index];
  const {3} end   = static_cast<const {3}*>(st->end_offsets)[index];
  const bool pred       = (end - begin) {4} st->threshold;
  *static_cast<bool*>(result_ptr) = pred;
}}
)XXX",
    selector_op_name,
    offset_t,
    cccl_type_enum_to_name(begin_offset_iterator.value_type.type),
    cccl_type_enum_to_name(end_offset_iterator.value_type.type),
    comparison);

  selector_op.type = cccl_op_kind_t::CCCL_STATEFUL;
  selector_op.name = selector_op_name;
  auto [lto_size, lto_buf] =
    begin_linking_nvrtc_program(static_cast<uint32_t>(num_lto_opts), lto_opts)
      ->add_program(nvrtc_translation_unit{code.c_str(), selector_op_name})
      ->compile_program({compile_args, num_compile_args})
      ->get_program_ltoir();
  char* code_copy = static_cast<char*>(std::malloc(lto_size));
  if (!code_copy)
  {
    throw std::bad_alloc();
  }
  std::memcpy(code_copy, lto_buf.get(), lto_size);
  selector_op.code      = code_copy;
  selector_op.code_size = lto_size;
  selector_op.code_type = CCCL_OP_LTOIR;
  selector_op.size      = sizeof(selector_state_t);
  selector_op.alignment = alignof(selector_state_t);
  // No state in the build result: it is per-call (see segmented_sort_kernel_source).
  selector_op.state = nullptr;

  return selector_op;
}

struct owned_selector_op
{
  cccl_op_t op{};
  owned_selector_op() = default;
  explicit owned_selector_op(cccl_op_t o)
      : op(o)
  {}
  ~owned_selector_op()
  {
    std::free(const_cast<char*>(op.code));
  }
  owned_selector_op(const owned_selector_op&)            = delete;
  owned_selector_op& operator=(const owned_selector_op&) = delete;
  cccl_op_t release()
  {
    cccl_op_t r = op;
    op          = {};
    return r;
  }
};

struct segmented_sort_kernel_source
{
  cccl_device_segmented_sort_build_result_t& build;
  selector_state_t* large_state;
  selector_state_t* small_state;

  CUkernel SegmentedSortFallbackKernel() const
  {
    return build.segmented_sort_fallback_kernel;
  }
  CUkernel SegmentedSortKernelSmall() const
  {
    return build.segmented_sort_kernel_small;
  }
  CUkernel SegmentedSortKernelLarge() const
  {
    return build.segmented_sort_kernel_large;
  }

  std::size_t KeySize() const
  {
    return build.key_type.size;
  }

  using LargeSegmentsSelectorT = indirect_arg_t;
  using SmallSegmentsSelectorT = indirect_arg_t;

  indirect_arg_t LargeSegmentsSelector(
    OffsetT offset, indirect_iterator_t begin_offset_iterator, indirect_iterator_t end_offset_iterator) const
  {
    large_state->initialize(offset, begin_offset_iterator, end_offset_iterator);
    // Same compiled op, pointed at this call's state instead of the shared one.
    cccl_op_t op = build.large_segments_selector_op;
    op.state     = large_state;
    return indirect_arg_t(op);
  }

  indirect_arg_t SmallSegmentsSelector(
    OffsetT offset, indirect_iterator_t begin_offset_iterator, indirect_iterator_t end_offset_iterator) const
  {
    small_state->initialize(offset, begin_offset_iterator, end_offset_iterator);
    cccl_op_t op = build.small_segments_selector_op;
    op.state     = small_state;
    return indirect_arg_t(op);
  }

  void SetSegmentOffset(indirect_arg_t& selector, long long base_segment_offset) const
  {
    auto* st                = static_cast<selector_state_t*>(selector.ptr);
    st->base_segment_offset = base_segment_offset;
  }
};

std::string get_three_way_partition_init_kernel_name()
{
  static constexpr std::string_view scan_tile_state_t = "cub::detail::three_way_partition::ScanTileStateT";

  static constexpr std::string_view num_selected_it_t = "cub::detail::segmented_sort::local_segment_index_t*";

  return std::format("cub::detail::three_way_partition::DeviceThreeWayPartitionInitKernel<{0}, {1}>",
                     scan_tile_state_t, // 0
                     num_selected_it_t); // 1
}

std::string get_three_way_partition_kernel_name(std::string_view large_selector_t, std::string_view small_selector_t)
{
  std::string policy_selector_t;
  check(cccl_type_name_from_nvrtc<device_three_way_partition_policy_selector>(&policy_selector_t));

  static constexpr std::string_view input_it_t =
    "thrust::counting_iterator<cub::detail::segmented_sort::local_segment_index_t>";
  static constexpr std::string_view first_out_it_t  = "cub::detail::segmented_sort::local_segment_index_t*";
  static constexpr std::string_view second_out_it_t = "cub::detail::segmented_sort::local_segment_index_t*";
  static constexpr std::string_view unselected_out_it_t =
    "thrust::reverse_iterator<cub::detail::segmented_sort::local_segment_index_t*>";
  static constexpr std::string_view num_selected_it_t = "cub::detail::segmented_sort::local_segment_index_t*";
  static constexpr std::string_view scan_tile_state_t = "cub::detail::three_way_partition::ScanTileStateT";
  std::string offset_t;
  check(cccl_type_name_from_nvrtc<OffsetT>(&offset_t));

  static constexpr std::string_view per_partition_offset_t = "cub::detail::three_way_partition::per_partition_offset_t";
  static constexpr std::string_view streaming_context_t =
    "cub::detail::three_way_partition::streaming_context_t<cub::detail::segmented_sort::global_segment_offset_t>";

  return std::format(
    "cub::detail::three_way_partition::DeviceThreeWayPartitionKernel<{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, "
    "{10}>",
    policy_selector_t, // 0 (PolicySelector)
    input_it_t, // 1 (InputIteratorT)
    first_out_it_t, // 2 (FirstOutputIteratorT)
    second_out_it_t, // 3 (SecondOutputIteratorT)
    unselected_out_it_t, // 4 (UnselectedOutputIteratorT)
    num_selected_it_t, // 5 (NumSelectedIteratorT)
    scan_tile_state_t, // 6 (ScanTileStateT)
    large_selector_t, // 7 (SelectFirstPartOp)
    small_selector_t, // 8 (SelectSecondPartOp)
    per_partition_offset_t, // 9 (OffsetT)
    streaming_context_t); // 10 (StreamingContextT)
}

struct partition_kernel_source
{
  cccl_device_segmented_sort_build_result_t& build;

  CUkernel ThreeWayPartitionInitKernel() const
  {
    return build.three_way_partition_init_kernel;
  }
  CUkernel ThreeWayPartitionKernel() const
  {
    return build.three_way_partition_kernel;
  }

  std::size_t OffsetSize() const
  {
    return build.offset_type.size;
  }
};
} // namespace segmented_sort

struct segmented_sort_keys_input_iterator_tag;
struct segmented_sort_keys_output_iterator_tag;
struct segmented_sort_values_input_iterator_tag;
struct segmented_sort_values_output_iterator_tag;
struct segmented_sort_start_offset_iterator_tag;
struct segmented_sort_end_offset_iterator_tag;
struct segmented_sort_large_selector_tag;
struct segmented_sort_small_selector_tag;

CUresult cccl_device_segmented_sort_compile(
  cccl_device_segmented_sort_build_result_t* build_ptr,
  cccl_sort_order_t sort_order,
  cccl_iterator_t keys_in_it,
  cccl_iterator_t values_in_it,
  cccl_iterator_t start_offset_it,
  cccl_iterator_t end_offset_it,
  int cc_major,
  int cc_minor,
  const char* cub_path,
  const char* thrust_path,
  const char* libcudacxx_path,
  const char* ctk_path,
  const cccl_build_config* config)
try
{
  if (cccl_iterator_kind_t::CCCL_POINTER != keys_in_it.type || cccl_iterator_kind_t::CCCL_POINTER != values_in_it.type)
  {
    fflush(stderr);
    printf("\nERROR in cccl_device_segmented_sort_build(): keys_in_it and values_in_it must be a pointer\n ");
    fflush(stdout);
    return CUDA_ERROR_UNKNOWN;
  }

  if (cccl_iterator_kind_t::CCCL_POINTER != start_offset_it.type
      || cccl_iterator_kind_t::CCCL_POINTER != end_offset_it.type)
  {
    fflush(stderr);
    printf("\nERROR in cccl_device_segmented_sort_build(): start_offset_it and end_offset_it must be a pointer\n ");
    fflush(stdout);
    return CUDA_ERROR_UNKNOWN;
  }

  const char* name = "device_segmented_sort";

  const auto [keys_in_iterator_name, keys_in_iterator_src] =
    get_specialization<segmented_sort_keys_input_iterator_tag>(template_id<input_iterator_traits>(), keys_in_it);

  const bool keys_only = values_in_it.type == cccl_iterator_kind_t::CCCL_POINTER && values_in_it.state == nullptr;

  std::string values_in_iterator_src;

  if (!keys_only)
  {
    const auto [vi_name, vi_src] =
      get_specialization<segmented_sort_values_input_iterator_tag>(template_id<input_iterator_traits>(), values_in_it);
    values_in_iterator_src = vi_src;
  }
  else
  {
    values_in_iterator_src = "";
  }

  const auto [start_offset_iterator_name, start_offset_iterator_src] =
    get_specialization<segmented_sort_start_offset_iterator_tag>(template_id<input_iterator_traits>(), start_offset_it);

  const auto [end_offset_iterator_name, end_offset_iterator_src] =
    get_specialization<segmented_sort_end_offset_iterator_tag>(template_id<input_iterator_traits>(), end_offset_it);

  const std::string key_t = cccl_type_enum_to_name(keys_in_it.value_type.type);
  const std::string value_t =
    keys_only ? "cub::NullType" : cccl_type_enum_to_name<items_storage_t>(values_in_it.value_type.type);

  const std::string arch = std::format("-arch=sm_{0}{1}", cc_major, cc_minor);

  std::vector<const char*> selector_compilation_args = {
    arch.c_str(),
    cub_path,
    thrust_path,
    libcudacxx_path,
    ctk_path,
    "-rdc=true",
    "-dlto",
    "-default-device",
    "-DCUB_DISABLE_CDP",
    "-std=c++20"};

  cccl::detail::extend_args_with_build_config(selector_compilation_args, config);

  constexpr size_t num_lto_args   = 2;
  const char* lopts[num_lto_args] = {"-lto", arch.c_str()};

  // TODO: we currently compile each selector op separately from the main TU.
  // We do this because we need to pass the selector ops to
  // DispatchThreeWayPartition eventually. This causes increased compilation
  // times, which might be avoidable.
  segmented_sort::owned_selector_op large_selector_op{segmented_sort::make_segments_selector_op(
    start_offset_it,
    end_offset_it,
    "cccl_large_segments_selector_op",
    ">",
    selector_compilation_args.data(),
    selector_compilation_args.size(),
    lopts,
    num_lto_args)};
  segmented_sort::owned_selector_op small_selector_op{segmented_sort::make_segments_selector_op(
    start_offset_it,
    end_offset_it,
    "cccl_small_segments_selector_op",
    "<",
    selector_compilation_args.data(),
    selector_compilation_args.size(),
    lopts,
    num_lto_args)};

  cccl_type_info selector_result_t{sizeof(bool), alignof(bool), cccl_type_enum::CCCL_BOOLEAN};
  cccl_type_info selector_input_t{
    sizeof(cub::detail::segmented_sort::local_segment_index_t),
    alignof(cub::detail::segmented_sort::local_segment_index_t),
    cccl_type_enum::CCCL_UINT32};

  const auto [large_selector_name, large_selector_src] = get_specialization<segmented_sort_large_selector_tag>(
    template_id<unary_user_operation_traits>(), large_selector_op.op, selector_result_t, selector_input_t);

  const auto [small_selector_name, small_selector_src] = get_specialization<segmented_sort_small_selector_tag>(
    template_id<unary_user_operation_traits>(), small_selector_op.op, selector_result_t, selector_input_t);

  const auto policy_sel = cub::detail::segmented_sort::policy_selector{
    static_cast<int>(keys_in_it.value_type.size),
    keys_only ? int{sizeof(cub::NullType)} : static_cast<int>(values_in_it.value_type.size),
    keys_only};

  // TODO(bgruber): drop this if tuning policies become formattable
  std::stringstream segmented_sort_policy_sel_str;
  segmented_sort_policy_sel_str << policy_sel(cuda::compute_capability{cc_major, cc_minor});

  const auto segmented_sort_policy_expr = std::format(
    "cub::detail::segmented_sort::policy_selector_from_types<{}, {}>",
    key_t, // 0
    value_t); // 1

  const auto partition_policy_sel = cub::detail::three_way_partition::policy_selector{
    cub::detail::classify_type<cub::detail::segmented_sort::local_segment_index_t>,
    int{sizeof(cub::detail::segmented_sort::local_segment_index_t)},
    int{sizeof(cub::detail::three_way_partition::per_partition_offset_t)}};

  // TODO(bgruber): drop this if tuning policies become formattable
  std::stringstream partition_policy_sel_str;
  partition_policy_sel_str << partition_policy_sel(cuda::compute_capability{cc_major, cc_minor});

  const auto three_way_partition_policy_expr = std::format(
    "cub::detail::three_way_partition::policy_selector_from_types<cub::detail::segmented_sort::local_segment_index_t, "
    "cub::detail::three_way_partition::per_partition_offset_t>");

  const std::string final_src = std::format(
    R"XXX(
#include <cub/device/dispatch/kernels/kernel_segmented_sort.cuh>
#include <cub/device/dispatch/tuning/tuning_segmented_sort.cuh>
#include <cub/device/dispatch/kernels/kernel_three_way_partition.cuh>
#include <cub/device/dispatch/tuning/tuning_three_way_partition.cuh>

{0}

#include <thrust/iterator/counting_iterator.h> // used in three_way_partition kernel
#include <thrust/iterator/reverse_iterator.h> // used in three_way_partition kernel
#include <cub/detail/choose_offset.cuh> // used in three_way_partition kernel

struct __align__({2}) storage_t {{
  char data[{1}];
}};
struct __align__({4}) items_storage_t {{
  char data[{3}];
}};
{5}
{6}
{7}
{8}
{9}
{10}
using device_segmented_sort_policy_selector = {11};
using device_three_way_partition_policy_selector = {13};
using namespace cub;
using namespace cub::detail;
using namespace cub::detail::segmented_sort;
using namespace cub::detail::three_way_partition;
static_assert(
  device_segmented_sort_policy_selector()(current_tuning_cc()) == {12},
  "Host generated and JIT compiled policy mismatch");
static_assert(
  device_three_way_partition_policy_selector()(current_tuning_cc()) == {14},
  "Host generated and JIT compiled three-way partition policy mismatch");
)XXX",
    jit_template_header_contents, // 0
    keys_in_it.value_type.size, // 1
    keys_in_it.value_type.alignment, // 2
    values_in_it.value_type.size, // 3
    values_in_it.value_type.alignment, // 4
    keys_in_iterator_src, // 5
    values_in_iterator_src, // 6
    start_offset_iterator_src, // 7
    end_offset_iterator_src, // 8
    large_selector_src, // 9
    small_selector_src, // 10
    segmented_sort_policy_expr, // 11
    segmented_sort_policy_sel_str.view(), // 12
    three_way_partition_policy_expr, // 13
    partition_policy_sel_str.view()); // 14

#if false // CCCL_DEBUGGING_SWITCH
  fflush(stderr);
  printf("\nCODE4NVRTC BEGIN\n%sCODE4NVRTC END\n", final_src.c_str());
  fflush(stdout);
#endif

  std::vector<const char*> args = {
    arch.c_str(),
    cub_path,
    thrust_path,
    libcudacxx_path,
    ctk_path,
    "-rdc=true",
    "-dlto",
    "-default-device",
    "-DCUB_DISABLE_CDP",
    "-std=c++20"};

  cccl::detail::extend_args_with_build_config(args, config);

  std::string segmented_sort_fallback_kernel_name = segmented_sort::get_device_segmented_sort_fallback_kernel_name(
    start_offset_iterator_name, end_offset_iterator_name, key_t, value_t, sort_order);

  std::string segmented_sort_kernel_small_name = segmented_sort::get_device_segmented_sort_kernel_small_name(
    start_offset_iterator_name, end_offset_iterator_name, key_t, value_t, sort_order);

  std::string segmented_sort_kernel_large_name = segmented_sort::get_device_segmented_sort_kernel_large_name(
    start_offset_iterator_name, end_offset_iterator_name, key_t, value_t, sort_order);

  std::string three_way_partition_init_kernel_name = segmented_sort::get_three_way_partition_init_kernel_name();

  std::string three_way_partition_kernel_name =
    segmented_sort::get_three_way_partition_kernel_name(large_selector_name, small_selector_name);

  std::string segmented_sort_fallback_kernel_lowered_name;
  std::string segmented_sort_kernel_small_lowered_name;
  std::string segmented_sort_kernel_large_lowered_name;
  std::string three_way_partition_init_kernel_lowered_name;
  std::string three_way_partition_kernel_lowered_name;

  // Collect all LTO-IRs to be linked.
  nvrtc_linkable_list linkable_list;
  nvrtc_linkable_list_appender appender{linkable_list};

  // add iterator definitions
  appender.add_iterator_definition(keys_in_it);
  if (!keys_only)
  {
    appender.add_iterator_definition(values_in_it);
  }
  appender.add_iterator_definition(start_offset_it);
  appender.add_iterator_definition(end_offset_it);

  appender.append_operation(large_selector_op.op);
  appender.append_operation(small_selector_op.op);

  nvrtc_link_result result =
    begin_linking_nvrtc_program(num_lto_args, lopts)
      ->add_program(nvrtc_translation_unit{final_src.c_str(), name})
      ->add_expression({segmented_sort_fallback_kernel_name})
      ->add_expression({segmented_sort_kernel_small_name})
      ->add_expression({segmented_sort_kernel_large_name})
      ->add_expression({three_way_partition_init_kernel_name})
      ->add_expression({three_way_partition_kernel_name})
      ->compile_program({args.data(), args.size()})
      ->get_name({segmented_sort_fallback_kernel_name, segmented_sort_fallback_kernel_lowered_name})
      ->get_name({segmented_sort_kernel_small_name, segmented_sort_kernel_small_lowered_name})
      ->get_name({segmented_sort_kernel_large_name, segmented_sort_kernel_large_lowered_name})
      ->get_name({three_way_partition_init_kernel_name, three_way_partition_init_kernel_lowered_name})
      ->get_name({three_way_partition_kernel_name, three_way_partition_kernel_lowered_name})
      ->link_program()
      ->add_link_list(linkable_list)
      ->finalize_program();

  struct free_deleter
  {
    void operator()(void* p) const
    {
      std::free(p);
    }
  };
  static_assert(::cuda::is_trivially_copyable_v<cub::detail::segmented_sort::policy_selector>);
  static_assert(::cuda::is_trivially_copyable_v<cub::detail::three_way_partition::policy_selector>);
  const size_t sort_policy_size      = sizeof(policy_sel);
  const size_t partition_policy_size = sizeof(partition_policy_sel);
  std::unique_ptr<void, free_deleter> sort_policy_ptr(std::malloc(sort_policy_size));
  if (!sort_policy_ptr)
  {
    return CUDA_ERROR_OUT_OF_MEMORY;
  }
  std::unique_ptr<void, free_deleter> partition_policy_ptr(std::malloc(partition_policy_size));
  if (!partition_policy_ptr)
  {
    return CUDA_ERROR_OUT_OF_MEMORY;
  }
  std::memcpy(sort_policy_ptr.get(), &policy_sel, sizeof(policy_sel));
  std::memcpy(partition_policy_ptr.get(), &partition_policy_sel, sizeof(partition_policy_sel));
  auto fallback_name   = std::unique_ptr<char[]>(duplicate_c_string(segmented_sort_fallback_kernel_lowered_name));
  auto small_name      = std::unique_ptr<char[]>(duplicate_c_string(segmented_sort_kernel_small_lowered_name));
  auto large_name      = std::unique_ptr<char[]>(duplicate_c_string(segmented_sort_kernel_large_lowered_name));
  auto twp_init_name   = std::unique_ptr<char[]>(duplicate_c_string(three_way_partition_init_kernel_lowered_name));
  auto twp_kernel_name = std::unique_ptr<char[]>(duplicate_c_string(three_way_partition_kernel_lowered_name));

  build_ptr->cc          = cc_major * 10 + cc_minor;
  build_ptr->key_type    = keys_in_it.value_type;
  build_ptr->offset_type = cccl_type_info{sizeof(OffsetT), alignof(OffsetT), cccl_type_enum::CCCL_INT64};
  build_ptr->order       = sort_order;
  // Zero-init fields set by _load, not _compile.
  build_ptr->library                         = nullptr;
  build_ptr->segmented_sort_fallback_kernel  = nullptr;
  build_ptr->segmented_sort_kernel_small     = nullptr;
  build_ptr->segmented_sort_kernel_large     = nullptr;
  build_ptr->three_way_partition_init_kernel = nullptr;
  build_ptr->three_way_partition_kernel      = nullptr;

  build_ptr->large_segments_selector_op = large_selector_op.release();
  build_ptr->small_segments_selector_op = small_selector_op.release();
  build_ptr->payload                    = (void*) result.data.release();
  build_ptr->payload_size               = result.size;
  build_ptr->payload_kind               = CCCL_PAYLOAD_CUBIN;

  build_ptr->runtime_policy                               = sort_policy_ptr.release();
  build_ptr->runtime_policy_size                          = sort_policy_size;
  build_ptr->partition_runtime_policy                     = partition_policy_ptr.release();
  build_ptr->partition_runtime_policy_size                = partition_policy_size;
  build_ptr->segmented_sort_fallback_kernel_lowered_name  = fallback_name.release();
  build_ptr->segmented_sort_kernel_small_lowered_name     = small_name.release();
  build_ptr->segmented_sort_kernel_large_lowered_name     = large_name.release();
  build_ptr->three_way_partition_init_kernel_lowered_name = twp_init_name.release();
  build_ptr->three_way_partition_kernel_lowered_name      = twp_kernel_name.release();

  return CUDA_SUCCESS;
}
catch (const std::exception& exc)
{
  fflush(stderr);
  printf("\nEXCEPTION in cccl_device_segmented_sort_compile(): %s\n", exc.what());
  fflush(stdout);

  return CUDA_ERROR_UNKNOWN;
}

CUresult cccl_device_segmented_sort_load(cccl_device_segmented_sort_build_result_t* build)
try
{
  auto invalid_name = [](const char* n) {
    return n == nullptr || n[0] == '\0';
  };
  if (build == nullptr || build->payload == nullptr || build->payload_size == 0
      || build->payload_kind != CCCL_PAYLOAD_CUBIN || invalid_name(build->segmented_sort_fallback_kernel_lowered_name)
      || invalid_name(build->segmented_sort_kernel_small_lowered_name)
      || invalid_name(build->segmented_sort_kernel_large_lowered_name)
      || invalid_name(build->three_way_partition_init_kernel_lowered_name)
      || invalid_name(build->three_way_partition_kernel_lowered_name))
  {
    return CUDA_ERROR_INVALID_VALUE;
  }
  CUresult status = cuLibraryLoadData(&build->library, build->payload, nullptr, nullptr, 0, nullptr, nullptr, 0);
  if (status != CUDA_SUCCESS)
  {
    return status;
  }
  try
  {
    check(cuLibraryGetKernel(
      &build->segmented_sort_fallback_kernel, build->library, build->segmented_sort_fallback_kernel_lowered_name));
    check(cuLibraryGetKernel(
      &build->segmented_sort_kernel_small, build->library, build->segmented_sort_kernel_small_lowered_name));
    check(cuLibraryGetKernel(
      &build->segmented_sort_kernel_large, build->library, build->segmented_sort_kernel_large_lowered_name));
    check(cuLibraryGetKernel(
      &build->three_way_partition_init_kernel, build->library, build->three_way_partition_init_kernel_lowered_name));
    check(cuLibraryGetKernel(
      &build->three_way_partition_kernel, build->library, build->three_way_partition_kernel_lowered_name));
  }
  catch (...)
  {
    cuLibraryUnload(build->library);
    build->library = nullptr;
    throw;
  }
  return CUDA_SUCCESS;
}
catch (const std::exception& exc)
{
  fflush(stderr);
  printf("\nEXCEPTION in cccl_device_segmented_sort_load(): %s\n", exc.what());
  fflush(stdout);
  return CUDA_ERROR_UNKNOWN;
}

CUresult cccl_device_segmented_sort_build_ex(
  cccl_device_segmented_sort_build_result_t* build_ptr,
  cccl_sort_order_t sort_order,
  cccl_iterator_t keys_in_it,
  cccl_iterator_t values_in_it,
  cccl_iterator_t start_offset_it,
  cccl_iterator_t end_offset_it,
  int cc_major,
  int cc_minor,
  const char* cub_path,
  const char* thrust_path,
  const char* libcudacxx_path,
  const char* ctk_path,
  const cccl_build_config* config)
{
  CUresult result = cccl_device_segmented_sort_compile(
    build_ptr,
    sort_order,
    keys_in_it,
    values_in_it,
    start_offset_it,
    end_offset_it,
    cc_major,
    cc_minor,
    cub_path,
    thrust_path,
    libcudacxx_path,
    ctk_path,
    config);
  if (result != CUDA_SUCCESS)
  {
    return result;
  }
  CUresult load_r = cccl_device_segmented_sort_load(build_ptr);
  if (load_r != CUDA_SUCCESS)
  {
    cccl_device_segmented_sort_cleanup(build_ptr);
  }
  return load_r;
}

CUresult cccl_device_segmented_sort_build(
  cccl_device_segmented_sort_build_result_t* build_ptr,
  cccl_sort_order_t sort_order,
  cccl_iterator_t keys_in_it,
  cccl_iterator_t values_in_it,
  cccl_iterator_t start_offset_it,
  cccl_iterator_t end_offset_it,
  int cc_major,
  int cc_minor,
  const char* cub_path,
  const char* thrust_path,
  const char* libcudacxx_path,
  const char* ctk_path)
{
  return cccl_device_segmented_sort_build_ex(
    build_ptr,
    sort_order,
    keys_in_it,
    values_in_it,
    start_offset_it,
    end_offset_it,
    cc_major,
    cc_minor,
    cub_path,
    thrust_path,
    libcudacxx_path,
    ctk_path,
    nullptr);
}

template <cub::SortOrder Order>
CUresult cccl_device_segmented_sort_impl(
  cccl_device_segmented_sort_build_result_t build,
  void* d_temp_storage,
  size_t* temp_storage_bytes,
  cccl_iterator_t d_keys_in,
  cccl_iterator_t d_keys_out,
  cccl_iterator_t d_values_in,
  cccl_iterator_t d_values_out,
  uint64_t num_items,
  uint64_t num_segments,
  cccl_iterator_t start_offset_in,
  cccl_iterator_t end_offset_in,
  bool is_overwrite_okay,
  int* selector,
  CUstream stream)
{
  if (selector == nullptr)
  {
    fflush(stderr);
    printf("\nERROR in cccl_device_segmented_sort(): selector cannot be nullptr\n");
    fflush(stdout);
    return CUDA_ERROR_UNKNOWN;
  }

  bool pushed    = false;
  CUresult error = CUDA_SUCCESS;
  try
  {
    pushed = try_push_context();

    CUdevice cu_device;
    check(cuCtxGetDevice(&cu_device));

    // Create DoubleBuffer structures for keys and values
    // CUB will handle keys-only vs key-value sorting internally
    indirect_arg_t key_arg_in{d_keys_in};
    indirect_arg_t key_arg_out{d_keys_out};
    cub::DoubleBuffer<indirect_arg_t> d_keys_double_buffer(
      *static_cast<indirect_arg_t**>(&key_arg_in), *static_cast<indirect_arg_t**>(&key_arg_out));

    indirect_arg_t val_arg_in{d_values_in};
    indirect_arg_t val_arg_out{d_values_out};
    cub::DoubleBuffer<indirect_arg_t> d_values_double_buffer(
      *static_cast<indirect_arg_t**>(&val_arg_in), *static_cast<indirect_arg_t**>(&val_arg_out));

    // Per-call state, stack-local so concurrent launches stay independent. Safe under
    // async: copied by value into kernel params at each launch within this dispatch.
    segmented_sort::selector_state_t large_selector_state{};
    segmented_sort::selector_state_t small_selector_state{};

    auto exec_status = cub::detail::segmented_sort::dispatch<Order, OffsetT>(
      d_temp_storage,
      *temp_storage_bytes,
      d_keys_double_buffer,
      d_values_double_buffer,
      num_items,
      num_segments,
      indirect_iterator_t{start_offset_in},
      indirect_iterator_t{end_offset_in},
      is_overwrite_okay,
      stream,
      /* policy_selector */
      *static_cast<cub::detail::segmented_sort::policy_selector*>(build.runtime_policy),
      /* partition_policy_selector */
      *static_cast<cub::detail::three_way_partition::policy_selector*>(build.partition_runtime_policy),
      /* kernel_source */
      segmented_sort::segmented_sort_kernel_source{build, &large_selector_state, &small_selector_state},
      /* partition_kernel_source */ segmented_sort::partition_kernel_source{build},
      /* launcher_factory */ cub::detail::CudaDriverLauncherFactory{cu_device, build.cc});

    *selector = d_keys_double_buffer.selector;
    error     = static_cast<CUresult>(exec_status);
  }
  catch (const std::exception& exc)
  {
    fflush(stderr);
    printf("\nEXCEPTION in cccl_device_segmented_sort(): %s\n", exc.what());
    fflush(stdout);
    error = CUDA_ERROR_UNKNOWN;
  }

  if (pushed)
  {
    CUcontext dummy;
    cuCtxPopCurrent(&dummy);
  }

  return error;
}

CUresult cccl_device_segmented_sort(
  cccl_device_segmented_sort_build_result_t build,
  void* d_temp_storage,
  size_t* temp_storage_bytes,
  cccl_iterator_t d_keys_in,
  cccl_iterator_t d_keys_out,
  cccl_iterator_t d_values_in,
  cccl_iterator_t d_values_out,
  uint64_t num_items,
  uint64_t num_segments,
  cccl_iterator_t start_offset_in,
  cccl_iterator_t end_offset_in,
  bool is_overwrite_okay,
  int* selector,
  CUstream stream)
{
  auto segmented_sort_impl =
    (build.order == CCCL_ASCENDING)
      ? cccl_device_segmented_sort_impl<cub::SortOrder::Ascending>
      : cccl_device_segmented_sort_impl<cub::SortOrder::Descending>;

  return segmented_sort_impl(
    build,
    d_temp_storage,
    temp_storage_bytes,
    d_keys_in,
    d_keys_out,
    d_values_in,
    d_values_out,
    num_items,
    num_segments,
    start_offset_in,
    end_offset_in,
    is_overwrite_okay,
    selector,
    stream);
}

CUresult cccl_device_segmented_sort_cleanup(cccl_device_segmented_sort_build_result_t* build_ptr)
try
{
  if (build_ptr == nullptr)
  {
    return CUDA_ERROR_INVALID_VALUE;
  }

  std::unique_ptr<char[]> payload(reinterpret_cast<char*>(build_ptr->payload));

  // Clean up the selector op code buffers (malloc-allocated, so use std::free)
  std::free(const_cast<char*>(build_ptr->large_segments_selector_op.code));
  std::free(const_cast<char*>(build_ptr->small_segments_selector_op.code));

  // Clean up the runtime policies
  std::free(build_ptr->runtime_policy);
  std::free(build_ptr->partition_runtime_policy);
  for (char* p :
       {build_ptr->segmented_sort_fallback_kernel_lowered_name,
        build_ptr->segmented_sort_kernel_small_lowered_name,
        build_ptr->segmented_sort_kernel_large_lowered_name,
        build_ptr->three_way_partition_init_kernel_lowered_name,
        build_ptr->three_way_partition_kernel_lowered_name})
  {
    delete[] p;
  }
  if (build_ptr->library != nullptr)
  {
    check(cuLibraryUnload(build_ptr->library));
  }

  return CUDA_SUCCESS;
}
catch (const std::exception& exc)
{
  fflush(stderr);
  printf("\nEXCEPTION in cccl_device_segmented_sort_cleanup(): %s\n", exc.what());
  fflush(stdout);

  return CUDA_ERROR_UNKNOWN;
}

CUresult cccl_device_segmented_sort_link_ltoir(
  cccl_device_segmented_sort_build_result_t* build_ptr,
  const void** input_blobs,
  const size_t* input_sizes,
  size_t num_inputs)
try
{
  if (build_ptr == nullptr || build_ptr->payload == nullptr || build_ptr->payload_size == 0
      || build_ptr->payload_kind != CCCL_PAYLOAD_LTOIR)
  {
    return CUDA_ERROR_INVALID_VALUE;
  }
  const int cc_major = build_ptr->cc / 10;
  const int cc_minor = build_ptr->cc % 10;
  std::vector<const void*> all_blobs;
  std::vector<size_t> all_sizes;
  all_blobs.push_back(build_ptr->payload);
  all_sizes.push_back(build_ptr->payload_size);
  if (num_inputs > 0 && (input_blobs == nullptr || input_sizes == nullptr))
  {
    return CUDA_ERROR_INVALID_VALUE;
  }
  for (size_t i = 0; i < num_inputs; ++i)
  {
    if (input_blobs[i] == nullptr || input_sizes[i] == 0)
    {
      return CUDA_ERROR_INVALID_VALUE;
    }
    all_blobs.push_back(input_blobs[i]);
    all_sizes.push_back(input_sizes[i]);
  }
  auto [cubin, cubin_size] = nvjitlink_link(all_blobs.data(), all_sizes.data(), all_blobs.size(), cc_major, cc_minor);
  delete[] static_cast<char*>(build_ptr->payload);
  build_ptr->payload      = (void*) cubin.release();
  build_ptr->payload_size = cubin_size;
  build_ptr->payload_kind = CCCL_PAYLOAD_CUBIN;
  return CUDA_SUCCESS;
}
catch (const std::exception& exc)
{
  printf("\nEXCEPTION in cccl_device_segmented_sort_link_ltoir(): %s\n", exc.what());
  return CUDA_ERROR_UNKNOWN;
}

namespace segmented_sort_serialization
{
// Selector op names are compile-time constants (set in make_segments_selector_op).
// Deserialize simply points back at these literals — cleanup never frees op.name.
inline constexpr const char* kLargeSegmentsName = "cccl_large_segments_selector_op";
inline constexpr const char* kSmallSegmentsName = "cccl_small_segments_selector_op";

inline void serialize_selector_op(cccl::serialization::buffer_writer& w, const cccl_op_t& op)
{
  w.write_pod<uint32_t>(static_cast<uint32_t>(op.type));
  w.write_pod<uint32_t>(static_cast<uint32_t>(op.code_type));
  w.write_blob(op.code, op.code_size);
  // op.size/op.alignment/op.state are intentionally not serialized: the selector
  // state is runtime-specific and fully reconstructed by deserialize_selector_op.
}

inline cccl_op_t deserialize_selector_op(cccl::serialization::buffer_reader& r, const char* fixed_name)
{
  cccl_op_t op{};
  const auto type_v = r.read_pod<uint32_t>();
  if (type_v > static_cast<uint32_t>(CCCL_MAXIMUM))
  {
    throw std::runtime_error(std::format("serialization blob: invalid selector op kind ({})", type_v));
  }
  op.type = static_cast<cccl_op_kind_t>(type_v);

  const auto code_type_v = r.read_pod<uint32_t>();
  if (code_type_v > static_cast<uint32_t>(CCCL_OP_CPP_SOURCE))
  {
    throw std::runtime_error(std::format("serialization blob: invalid selector op code type ({})", code_type_v));
  }
  op.code_type = static_cast<cccl_op_code_type>(code_type_v);

  // code blob — hold in RAII until commit so a throw during read_bytes doesn't leak
  uint64_t code_n = r.read_pod<uint64_t>();
  std::unique_ptr<void, decltype(&std::free)> code_owner(nullptr, std::free);
  if (code_n > 0)
  {
    code_owner.reset(std::malloc(static_cast<size_t>(code_n)));
    if (!code_owner)
    {
      throw std::bad_alloc{};
    }
    r.read_bytes(code_owner.get(), static_cast<size_t>(code_n));
  }

  // No selector state to reconstruct (it is per-call). op.size stays hardcoded so a
  // malformed blob cannot dictate it.
  using segmented_sort::selector_state_t;

  // commit — no throws past this point
  op.size      = sizeof(selector_state_t);
  op.alignment = alignof(selector_state_t);
  op.code      = static_cast<const char*>(code_owner.release());
  op.code_size = static_cast<size_t>(code_n);
  op.state     = nullptr;
  // op.name is not freed by cleanup; safe to point at a string literal.
  op.name = fixed_name;
  // Selector ops never carry extra ltoirs in this codepath.
  op.extra_ltoirs      = nullptr;
  op.extra_ltoir_sizes = nullptr;
  op.num_extra_ltoirs  = 0;
  return op;
}
} // namespace segmented_sort_serialization

CUresult cccl_device_segmented_sort_serialize(
  const cccl_device_segmented_sort_build_result_t* build_ptr, void** out_buf, size_t* out_size)
try
{
  if (build_ptr == nullptr || out_buf == nullptr || out_size == nullptr)
  {
    return CUDA_ERROR_INVALID_VALUE;
  }
  if (build_ptr->payload == nullptr || build_ptr->payload_size == 0 || build_ptr->runtime_policy == nullptr
      || build_ptr->runtime_policy_size == 0 || build_ptr->partition_runtime_policy == nullptr
      || build_ptr->partition_runtime_policy_size == 0)
  {
    *out_buf  = nullptr;
    *out_size = 0;
    return CUDA_ERROR_INVALID_VALUE;
  }

  using namespace cccl::serialization;
  buffer_writer w;
  write_header(w, CCCL_SERIALIZATION_ALGO_SEGMENTED_SORT, build_ptr->payload_kind, build_ptr->cc);
  write_type_info(w, build_ptr->key_type);
  write_type_info(w, build_ptr->offset_type);
  w.write_pod<uint32_t>(static_cast<uint32_t>(build_ptr->order));
  segmented_sort_serialization::serialize_selector_op(w, build_ptr->large_segments_selector_op);
  segmented_sort_serialization::serialize_selector_op(w, build_ptr->small_segments_selector_op);
  w.write_blob(build_ptr->payload, build_ptr->payload_size);
  w.write_blob(build_ptr->runtime_policy, build_ptr->runtime_policy_size);
  w.write_blob(build_ptr->partition_runtime_policy, build_ptr->partition_runtime_policy_size);
  w.write_cstring(build_ptr->segmented_sort_fallback_kernel_lowered_name);
  w.write_cstring(build_ptr->segmented_sort_kernel_small_lowered_name);
  w.write_cstring(build_ptr->segmented_sort_kernel_large_lowered_name);
  w.write_cstring(build_ptr->three_way_partition_init_kernel_lowered_name);
  w.write_cstring(build_ptr->three_way_partition_kernel_lowered_name);
  w.release(out_buf, out_size);
  return CUDA_SUCCESS;
}
catch (const std::exception& exc)
{
  fflush(stderr);
  printf("\nEXCEPTION in cccl_device_segmented_sort_serialize(): %s\n", exc.what());
  fflush(stdout);
  return CUDA_ERROR_UNKNOWN;
}

CUresult cccl_device_segmented_sort_deserialize(
  cccl_device_segmented_sort_build_result_t* build_ptr, const void* buf, size_t size)
try
{
  if (build_ptr == nullptr || buf == nullptr || size == 0)
  {
    return CUDA_ERROR_INVALID_VALUE;
  }

  using namespace cccl::serialization;
  buffer_reader r{buf, size};
  const auto h = read_and_validate_header(r, CCCL_SERIALIZATION_ALGO_SEGMENTED_SORT);

  const auto key_t    = read_type_info(r);
  const auto offset_t = read_type_info(r);
  const auto order    = static_cast<cccl_sort_order_t>(r.read_pod<uint32_t>());
  if (order != CCCL_ASCENDING && order != CCCL_DESCENDING)
  {
    throw std::runtime_error(std::format("serialization blob: invalid sort order ({})", static_cast<uint32_t>(order)));
  }

  // selector ops own a malloc'd code buffer (state is per-call now, so nullptr
  // here). If a later step throws, the catch handlers below std::free the code.
  cccl_op_t large_op =
    segmented_sort_serialization::deserialize_selector_op(r, segmented_sort_serialization::kLargeSegmentsName);
  cccl_op_t small_op{};
  try
  {
    small_op =
      segmented_sort_serialization::deserialize_selector_op(r, segmented_sort_serialization::kSmallSegmentsName);
  }
  catch (...)
  {
    std::free(const_cast<char*>(large_op.code));
    throw;
  }

  std::unique_ptr<char[]> payload_owner;
  size_t payload_size = 0;
  try
  {
    void* p = nullptr;
    r.read_blob_new(&p, &payload_size);
    payload_owner.reset(static_cast<char*>(p));
  }
  catch (...)
  {
    std::free(const_cast<char*>(large_op.code));
    std::free(const_cast<char*>(small_op.code));
    throw;
  }
  if (payload_size == 0)
  {
    std::free(const_cast<char*>(large_op.code));
    std::free(const_cast<char*>(small_op.code));
    throw std::runtime_error("serialization blob: empty payload");
  }

  std::unique_ptr<cub::detail::segmented_sort::policy_selector, decltype(&std::free)> sort_policy(nullptr, std::free);
  std::unique_ptr<cub::detail::three_way_partition::policy_selector, decltype(&std::free)> partition_policy(
    nullptr, std::free);
  std::unique_ptr<char[]> n_fb;
  std::unique_ptr<char[]> n_small;
  std::unique_ptr<char[]> n_large;
  std::unique_ptr<char[]> n_init;
  std::unique_ptr<char[]> n_part;
  try
  {
    sort_policy.reset(static_cast<cub::detail::segmented_sort::policy_selector*>(
      std::malloc(sizeof(cub::detail::segmented_sort::policy_selector))));
    if (!sort_policy)
    {
      throw std::bad_alloc{};
    }
    r.read_into(sort_policy.get(), sizeof(cub::detail::segmented_sort::policy_selector));
    partition_policy.reset(static_cast<cub::detail::three_way_partition::policy_selector*>(
      std::malloc(sizeof(cub::detail::three_way_partition::policy_selector))));
    if (!partition_policy)
    {
      throw std::bad_alloc{};
    }
    r.read_into(partition_policy.get(), sizeof(cub::detail::three_way_partition::policy_selector));
    n_fb.reset(r.read_cstring_dup());
    n_small.reset(r.read_cstring_dup());
    n_large.reset(r.read_cstring_dup());
    n_init.reset(r.read_cstring_dup());
    n_part.reset(r.read_cstring_dup());
  }
  catch (...)
  {
    std::free(const_cast<char*>(large_op.code));
    std::free(const_cast<char*>(small_op.code));
    throw;
  }

  cccl_device_segmented_sort_build_result_t result{};
  result.cc                                           = static_cast<int>(h.cc);
  result.payload_kind                                 = static_cast<cccl_payload_kind_t>(h.payload_kind);
  result.key_type                                     = key_t;
  result.offset_type                                  = offset_t;
  result.order                                        = order;
  result.large_segments_selector_op                   = large_op;
  result.small_segments_selector_op                   = small_op;
  result.payload                                      = payload_owner.release();
  result.payload_size                                 = payload_size;
  result.runtime_policy                               = sort_policy.release();
  result.runtime_policy_size                          = sizeof(cub::detail::segmented_sort::policy_selector);
  result.partition_runtime_policy                     = partition_policy.release();
  result.partition_runtime_policy_size                = sizeof(cub::detail::three_way_partition::policy_selector);
  result.segmented_sort_fallback_kernel_lowered_name  = n_fb.release();
  result.segmented_sort_kernel_small_lowered_name     = n_small.release();
  result.segmented_sort_kernel_large_lowered_name     = n_large.release();
  result.three_way_partition_init_kernel_lowered_name = n_init.release();
  result.three_way_partition_kernel_lowered_name      = n_part.release();
  *build_ptr                                          = result;
  return CUDA_SUCCESS;
}
catch (const std::exception& exc)
{
  fflush(stderr);
  printf("\nEXCEPTION in cccl_device_segmented_sort_deserialize(): %s\n", exc.what());
  fflush(stdout);
  return CUDA_ERROR_UNKNOWN;
}
